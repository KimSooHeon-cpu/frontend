var id = 0;
function _classPrivateFieldKey(e) {
  return "__private_" + id++ + "_" + e;
}
module.exports = _classPrivateFieldKey, module.exports.__esModule = true, module.exports["default"] = module.exports;