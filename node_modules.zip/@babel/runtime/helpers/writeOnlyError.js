function _writeOnlyError(r) {
  throw new TypeError('"' + r + '" is write-only');
}
module.exports = _writeOnlyError, module.exports.__esModule = true, module.exports["default"] = module.exports;