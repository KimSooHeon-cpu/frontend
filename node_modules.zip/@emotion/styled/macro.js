module.exports = require('@emotion/babel-plugin').macros.webStyled
