import styled from '@emotion/styled'
export * from '@emotion/styled'
export default styled
