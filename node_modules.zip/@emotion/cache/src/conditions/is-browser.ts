export default typeof document !== 'undefined'
