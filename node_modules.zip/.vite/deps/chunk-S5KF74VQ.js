import {
  require_react
} from "./chunk-BQYK6RGN.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/@mui/material/esm/Table/Tablelvl2Context.js
var React = __toESM(require_react(), 1);
var Tablelvl2Context = React.createContext();
if (true) {
  Tablelvl2Context.displayName = "Tablelvl2Context";
}
var Tablelvl2Context_default = Tablelvl2Context;

export {
  Tablelvl2Context_default
};
//# sourceMappingURL=chunk-S5KF74VQ.js.map
