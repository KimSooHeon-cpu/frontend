import {
  useForkRef
} from "./chunk-E4MPIUBI.js";

// node_modules/@mui/material/esm/utils/useForkRef.js
var useForkRef_default = useForkRef;

export {
  useForkRef_default
};
//# sourceMappingURL=chunk-XKY3NZBG.js.map
