import {
  useEnhancedEffect_default
} from "./chunk-AW2V2HHY.js";

// node_modules/@mui/material/esm/utils/useEnhancedEffect.js
var useEnhancedEffect_default2 = useEnhancedEffect_default;

export {
  useEnhancedEffect_default2 as useEnhancedEffect_default
};
//# sourceMappingURL=chunk-2TLGKT2O.js.map
