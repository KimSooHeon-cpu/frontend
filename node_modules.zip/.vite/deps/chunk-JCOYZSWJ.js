import {
  capitalize
} from "./chunk-AW2V2HHY.js";

// node_modules/@mui/material/esm/utils/capitalize.js
var capitalize_default = capitalize;

export {
  capitalize_default
};
//# sourceMappingURL=chunk-JCOYZSWJ.js.map
