import {
  require_react
} from "./chunk-BQYK6RGN.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
