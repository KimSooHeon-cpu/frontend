import {
  require_react
} from "./chunk-BQYK6RGN.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/@mui/material/esm/Table/TableContext.js
var React = __toESM(require_react(), 1);
var TableContext = React.createContext();
if (true) {
  TableContext.displayName = "TableContext";
}
var TableContext_default = TableContext;

export {
  TableContext_default
};
//# sourceMappingURL=chunk-XPCRBI63.js.map
