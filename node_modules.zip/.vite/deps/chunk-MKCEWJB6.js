import {
  require_react
} from "./chunk-BQYK6RGN.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/@mui/material/esm/RadioGroup/useRadioGroup.js
var React2 = __toESM(require_react(), 1);

// node_modules/@mui/material/esm/RadioGroup/RadioGroupContext.js
var React = __toESM(require_react(), 1);
var RadioGroupContext = React.createContext(void 0);
if (true) {
  RadioGroupContext.displayName = "RadioGroupContext";
}
var RadioGroupContext_default = RadioGroupContext;

// node_modules/@mui/material/esm/RadioGroup/useRadioGroup.js
function useRadioGroup() {
  return React2.useContext(RadioGroupContext_default);
}

export {
  RadioGroupContext_default,
  useRadioGroup
};
//# sourceMappingURL=chunk-MKCEWJB6.js.map
