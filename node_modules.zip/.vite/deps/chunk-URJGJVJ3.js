import {
  defaultTheme_default
} from "./chunk-EVWGGYJN.js";
import {
  identifier_default,
  useTheme_default
} from "./chunk-AW2V2HHY.js";
import {
  require_react
} from "./chunk-BQYK6RGN.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/@mui/material/esm/styles/useTheme.js
var React = __toESM(require_react(), 1);
function useTheme() {
  const theme = useTheme_default(defaultTheme_default);
  if (true) {
    React.useDebugValue(theme);
  }
  return theme[identifier_default] || theme;
}

export {
  useTheme
};
//# sourceMappingURL=chunk-URJGJVJ3.js.map
