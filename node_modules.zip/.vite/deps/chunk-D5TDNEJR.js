import {
  isMuiElement
} from "./chunk-EVWGGYJN.js";

// node_modules/@mui/material/esm/utils/isMuiElement.js
var isMuiElement_default = isMuiElement;

export {
  isMuiElement_default
};
//# sourceMappingURL=chunk-D5TDNEJR.js.map
