import {
  useId
} from "./chunk-EVWGGYJN.js";

// node_modules/@mui/material/esm/utils/useId.js
var useId_default = useId;

export {
  useId_default
};
//# sourceMappingURL=chunk-5I2Q4N6O.js.map
