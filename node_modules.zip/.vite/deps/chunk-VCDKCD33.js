import {
  identifier_default,
  unstable_createUseMediaQuery
} from "./chunk-AW2V2HHY.js";

// node_modules/@mui/material/esm/useMediaQuery/index.js
var useMediaQuery = unstable_createUseMediaQuery({
  themeId: identifier_default
});
var useMediaQuery_default = useMediaQuery;

export {
  useMediaQuery_default
};
//# sourceMappingURL=chunk-VCDKCD33.js.map
