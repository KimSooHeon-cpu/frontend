import {
  unstable_memoTheme
} from "./chunk-EVWGGYJN.js";

// node_modules/@mui/material/esm/utils/memoTheme.js
var memoTheme = unstable_memoTheme;
var memoTheme_default = memoTheme;

export {
  memoTheme_default
};
//# sourceMappingURL=chunk-RZEPZDLX.js.map
