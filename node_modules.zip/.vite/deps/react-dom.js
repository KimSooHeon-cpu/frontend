import {
  require_react_dom
} from "./chunk-D7552MD7.js";
import "./chunk-BQYK6RGN.js";
import "./chunk-G3PMV62Z.js";
export default require_react_dom();
